package com.webtest.demo;

import java.io.IOException;

import javax.faces.component.UIColumn;

import org.apache.xmlbeans.impl.xb.xsdschema.Public;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.webtest.core.BaseTest;
import com.webtest.dataprovider.ExcelDataProvider;

public class ShoppingcartTest extends BaseTest{

	//未登录进行商品添加
	@Test(priority = 1)
	public void unlogin() throws InterruptedException{
		webtest.open("http://127.0.0.1:65/");
		Thread.sleep(3000);
		webtest.type("class=ecsc-search-input", "huawei");
		webtest.click("class=ecsc-search-button");
		Thread.sleep(2000);
		webtest.click("xpath=/html/body/div[4]/div/div[2]/div[2]/ul/li[1]/div/div[4]/a");
		Thread.sleep(2000);
		webtest.click("id=join_cart");
		Thread.sleep(1000);
		webtest.click("class=layui-layer-ico");
		Thread.sleep(2000);
	}
	
	@DataProvider(name="search")
	public Object[][] searchTestdemo() throws IOException{
		ExcelDataProvider data=new ExcelDataProvider();
		return data.getTestDataByExcel("E://TpShopDemo//TestDemoData.xlsx", "Sheet3");
	}
	//登录将商品加入购物车
	@Test(priority = 2,dataProvider="search")
	public void longined(String userName,String password,String mss) throws InterruptedException {
		webtest.click("xpath=//a[text()='登录']");
		webtest.type("id=username", userName);
		webtest.type("id=password", password);
		webtest.type("id=verify_code", mss);
		webtest.click("class=J-login-submit");
		Thread.sleep(2000);
		webtest.click("class=home");
		Thread.sleep(2000);
		webtest.click("xpath=/html/body/div[4]/div[2]/div/div[1]/div/div[6]/a/div/img");
		Thread.sleep(2000);
		webtest.click("id=join_cart");
		Thread.sleep(2000);
	}
	//移到我的收藏功能
	@Test(priority = 3)
	public void addcollect() throws InterruptedException {
		webtest.click("class=layui-layer-ico");
		Thread.sleep(1000);
		webtest.click("class=c-n");
		Thread.sleep(2000);
		webtest.click("class=collectAll");
		Thread.sleep(1000);
	}
	//结算功能
	@Test(priority = 4)
	public void getmoney() throws InterruptedException {
//		webtest.click("xpath=//div[class=cart-checkbox]/i");
//		webtest.click("/html/body/div[3]/div[3]/div[1]/div/div/div[1]/div[1]/i");
		webtest.click("class=paytotal");
		Thread.sleep(2000);
		webtest.click("class=addr-switch");
		webtest.click("class=curtr");
		webtest.click("id=submit_order");
		Thread.sleep(3000);
	}

	
	@Test(priority = 5)
	public void deleteOne() throws InterruptedException {
		webtest.click("xpath=/html/body/div[2]/div/div[1]/div/div[1]/div/a");
		Thread.sleep(1000);
		webtest.click("class=c-n");
		Thread.sleep(1000);
//		webtest.open("http://127.0.0.1:65/index.php/Home/Cart/index.html");
		webtest.click("/html/body/div[3]/div[3]/div[1]/div/div/div[6]/p[1]/a");
		Thread.sleep(2000);
		
//		WebElement element0=driver.findElement(By.xpath("//*[@id=\"removeGoods\"]"));
		webtest.click("xpath=//div[@class='op-btns']");
		Thread.sleep(1000);
	}
	@Test(priority = 6)
	public void deleteAll() throws InterruptedException {
		webtest.click("xpth=/html/body/div[3]/div[2]/div/div/div[1]/i");
		Thread.sleep(1000);
		webtest.click("class=deleteAll");
		webtest.click("/html/body/div[3]/div[3]/div[1]/div/div/div[6]/p[1]/a");
		Thread.sleep(1000);
		webtest.click("xpath=//div[@class='op-btns']");
		Thread.sleep(1000);
	}
	
}
