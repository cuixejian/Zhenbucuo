package com.webtest.demo;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.ClickAction;
import org.openqa.selenium.remote.server.handler.FindElement;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.webtest.core.BaseTest;
import com.webtest.dataprovider.ExcelDataProvider;

public class PageManagement extends BaseTest{

	@DataProvider(name="search")
	public Object[][] searchTestdemo() throws IOException{
		ExcelDataProvider data=new ExcelDataProvider();
		return data.getTestDataByExcel("E://TpShopDemo//TestDemoData.xlsx", "Sheet2");
	}
	//登录
	@Test(priority=1,dataProvider="search")
	public void Login(String userName,String password,String mss) throws InterruptedException {
		webtest.open("http://127.0.0.1:65/index.php/Admin/Admin/login");
		Thread.sleep(1000);
		webtest.type("name=username", userName);
		webtest.type("name=password", password);
		webtest.type("name=vertify", mss);
		webtest.click("class=sub");
		Thread.sleep(3000);
	}
	//添加模板
	@Test(priority = 2)
	public void addModel() throws InterruptedException {
		webtest.click("xpath=//a[text()='页面']");
		Thread.sleep(3000);
		webtest.enterFrame("workspace");
		webtest.click("xpath=/html/body/div[3]/div[1]/div/ul/li[2]/a");
		Thread.sleep(4000);
		Actions action=new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath("/html/body/div[3]/div[4]/div[2]/div[1]"))).perform();
		webtest.click("xpath=/html/body/div[3]/div[4]/div[2]/div[1]/div[2]/div[3]");
		Thread.sleep(2000);
	}
	//删除模板
	@Test(priority = 3)
	public void deleteModel() throws InterruptedException {
		
		webtest.click("xpath=//span[text()='我的模板']");
		Thread.sleep(2000);
		Actions action=new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath("//*[@id='my-template']/div/div[2]"))).perform();
		webtest.click("xpath=/html/body/div[3]/div[3]/div/div[2]/div[2]/div[2]/div[2]");
		Thread.sleep(2000);
		webtest.click("class=layui-layer-btn0");
		Thread.sleep(2000);
	}
	//模板分类管理——新增行业
	@Test(priority = 4)
	public void Addtrade() throws InterruptedException {
		webtest.leaveFrame();
		webtest.click("xpath=//a[text()='模板分类管理']");
		Thread.sleep(2000);
		webtest.enterFrame("workspace");
		webtest.click("xpath=//div[@title='新增分类']\"");
		Thread.sleep(2000);
		webtest.type("name=name", "AddTest");
		webtest.type("name=sort_order", "111");
		Thread.sleep(1000);
		webtest.click("id=submitBtn");
		Thread.sleep(2000);
	}
	//编辑行业信息
	@Test(priority = 5)
	public void Changetrade() throws InterruptedException {
		Actions action=new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath("//tbody[@id='treet1']/tr[2]/td[2]/div/span/em"))).perform();
		driver.findElement(By.xpath("//tbody[@id='treet1']/tr[2]/td[2]/div/span/ul/li[1]/a")).click();
		Thread.sleep(2000);
		driver.findElement(By.name("name")).sendKeys("change");
		Thread.sleep(1000);
		driver.findElement(By.id("submitBtn")).click();
		Thread.sleep(3000);
	}
	//删除行业
	@Test(priority = 6)
	public void Deletetrade() throws InterruptedException {
		Actions action=new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath("/html/body/div[1]/form/div/div[3]/table/tbody/tr[3]/td[2]/div/span/em"))).perform();
		Thread.sleep(2000);
		webtest.click("xpath=/html/body/div[1]/form/div/div[3]/table/tbody/tr[3]/td[2]/div/span/ul/li[2]/a");
	
		Thread.sleep(2000);
		webtest.click("class=layui-layer-btn0");
		Thread.sleep(3000);
	}
//	修改会员中心自定义信息
	@Test(priority = 7)
	public void ChangeVIP() throws InterruptedException {
		webtest.leaveFrame();
		webtest.click("xpath=//a[text()='会员中心自定义']");
		Thread.sleep(2000);
		webtest.enterFrame("workspace");
		webtest.click("xpath=//div[@id='cp2']/span[1]/i");
		
		Thread.sleep(1000);
		webtest.type("xpath=//input[@value='订单列表']", "111");
		Thread.sleep(1000);
		webtest.click("id=submit");
		driver.findElement(By.id("submit"));
		Thread.sleep(3000);
	}
	//启用手机端模板
	@Test(priority = 8)
	public void startModel() throws InterruptedException {
		webtest.leaveFrame();
		webtest.click("xpath=//a[text()='模板切换']");
		Thread.sleep(2000);
		webtest.enterFrame("workspace");
		webtest.click("xpath=//span[text()='手机端模板']");
		Thread.sleep(2000);
		webtest.click("xpath=//a[text()='启用']");
		Thread.sleep(3000);
	}
	//PC端导航栏——新增导航
	@Test(priority = 9)
	public void Addnavi() throws InterruptedException {
		webtest.leaveFrame();
		webtest.click("xpath=//a[text()='PC端导航栏']");
		Thread.sleep(2000);
		webtest.enterFrame("workspace");
		webtest.click("xpath=//span[text()='新增导航']");
		Thread.sleep(3000);
		webtest.type("id=name", "Test");
		webtest.type("id=url", "www.baidu.com");
		webtest.type("id=sort", "1111");
		webtest.click("id=submitBtn");
		Thread.sleep(4000);
	}
	//编辑导航
	@Test(priority = 10)
	public void Changenavi() throws InterruptedException {
		
		webtest.click("xpath=/html/body/div[3]/div[3]/div[3]/div[1]/table/tbody/tr[1]/td[8]/div/a[3]");
//		driver.findElement(By.xpath("//div[@class='bDiv']/div[1]/table/tbody/tr[1]/td[8]/div/a[3]")).click();
		Thread.sleep(2000);
		webtest.type("id=name","11");
		webtest.click("id=submitBtn");
		Thread.sleep(4000);
	}
	//删除导航
	@Test(priority = 11)
	public void Deletenavi() throws InterruptedException {
		webtest.click("xpath=/html/body/div[3]/div[3]/div[3]/div[1]/table/tbody/tr[1]/td[8]/div/a[2]");
		Thread.sleep(4000);
	}
	
}
