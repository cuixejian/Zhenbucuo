package com.webtest.demo;

import java.io.IOException;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.webtest.core.BaseTest;
import com.webtest.dataprovider.ExcelDataProvider;

public class ContentManagement extends BaseTest{

	@DataProvider(name="search")
	public Object[][] searchTestdemo() throws IOException{
		ExcelDataProvider data=new ExcelDataProvider();
		return data.getTestDataByExcel("E://TpShopDemo//TestDemoData.xlsx", "Sheet2");
	}
	//登录
	@Test(priority=1,dataProvider="search")
	public void Login(String userName,String password,String mss) throws InterruptedException {
		webtest.open("http://127.0.0.1:65/index.php/Admin/Admin/login");
		Thread.sleep(1000);
		webtest.type("name=username", userName);
		webtest.type("name=password", password);
		webtest.type("name=vertify", mss);
		webtest.click("class=sub");
		Thread.sleep(3000);
	}
	//文章列表-新增文章
	@Test(priority = 2)
	public void addMessage() throws InterruptedException {
		webtest.click("xpath=//a[text()='页面']");
		Thread.sleep(3000);
		webtest.click("xpath=//a[text()='文章列表']");
		Thread.sleep(2000);
		webtest.enterFrame("workspace");
		webtest.click("xpath=//div[@title='新增文章']");
		Thread.sleep(2000);
		webtest.type("xpath=//input[@name='title']","TestDemo");
		Thread.sleep(1000);
		webtest.click("id=cat_id");
		webtest.click("xpath=//option[@value='1']");
		webtest.type("xpath=//input[@name='keywords']","test");
		Thread.sleep(1000);	
		webtest.type("xpath=//input[@name='link']","http://www.baidu.com");
		webtest.click("xpath=//label[@text()='是']");
		Thread.sleep(1000);	
		webtest.type("id=post_description", "TestDemo");
		Thread.sleep(1000);	
		webtest.enterFrame("ueditor_0");
		webtest.type("xpath=//body[@class='view']","Test111");
		webtest.leaveFrame1();
		webtest.click("id=submitBtn");
		Thread.sleep(2000);
	}
	//查看文章
	@Test(priority = 3)
	public void ReadMessage() throws InterruptedException {
		webtest.click("xpath=//div[@id='flexigrid']/table/tbody/tr/td[6]/div/a[1]");
		Thread.sleep(3000);
	}
	//编辑文章
	@Test(priority = 4)
	public void ChangeMessage() throws InterruptedException {
		webtest.click("xpath=//div[@id='flexigrid']/table/tbody/tr/td[6]/div/a[3]");
		Thread.sleep(1000);
		webtest.type("xpath=//div[@class='ncap-form-default']/dl/dd/input", "1");
		webtest.click("id=submitBtn");
		Thread.sleep(2000);
	}
	//删除文章
	@Test(priority = 5)
	public void DeleteMessage() throws InterruptedException {
		webtest.click("xpath=/html/body/div[3]/div[3]/div[3]/div[1]/table/tbody/tr[1]/td[6]/div/a[2]");
		Thread.sleep(1000);
		webtest.click("class=layui-layer-btn0");
		Thread.sleep(2000);
	}
	//搜索文章
	@Test(priority = 6)
	public void SearchMessage() throws InterruptedException {
		webtest.click("class=select");
		webtest.click("xpath=//option[@value='1']");
		webtest.type("class=qsbox","sss");
		Thread.sleep(1000);
		webtest.click("xpath=//input[@type='submit']");
		Thread.sleep(2000);
	}
	//帮助分类——新增分类
	@Test(priority = 7)
	public void Addkind() throws InterruptedException {
		webtest.leaveFrame();
		webtest.click("xpath=//a[text()='帮助分类']");
		Thread.sleep(2000);
		webtest.enterFrame("workspace");
		webtest.click("xpath=//div[@title='新增分类']");
		Thread.sleep(1000);
		webtest.type(("xpath=//input[@name='cat_name']"),"Test");
		Thread.sleep(1000);
		webtest.click("id=parent_id");
		webtest.click("xpath=//option[@value='1']");
		
		Thread.sleep(1000);
		webtest.click("xpath=//label[text()='是']");
		Thread.sleep(1000);
		webtest.type(("xpath=//input[@name='sort_order']"),"2");
		Thread.sleep(1000);
		webtest.type(("xpath=//input[@name='keywords']"),"test");
		Thread.sleep(1000);
		webtest.type(("xpath=//input[@name='cat_desc']"),"test11");
		webtest.click("id=submitBtn");
		Thread.sleep(2000);
	}

//	//收缩分类
	@Test(priority = 8)
	public void smallKind() throws InterruptedException {
		webtest.click("xpath=//div[@title='收缩分类']");
		Thread.sleep(2000);
		webtest.click("xpath=//div[@title='收缩分类']");
		Thread.sleep(3000);
	}
	//编辑分类信息
	@Test(priority = 9)
	public void ChangeKind() throws InterruptedException {
		Actions action=new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath("/html/body/div/form/div/div[4]/table/tbody/tr[3]/td[2]/div/span/em"))).perform();
		webtest.click("xpath=/html/body/div/form/div/div[4]/table/tbody/tr[3]/td[2]/div/span/ul/li[1]/a");
		Thread.sleep(2000);
		webtest.type("xpath=//input[@name='cat_name']","C");
		webtest.click("id=submitBtn");
		Thread.sleep(3000);
	}
//	//新增下级分类
	@Test(priority = 10)
	public void AddNextKind() throws InterruptedException {
		Actions action=new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath("/html/body/div/form/div/div[4]/table/tbody/tr[2]/td[2]/div/span/em"))).perform();
		webtest.click("xpath=/html/body/div/form/div/div[4]/table/tbody/tr[2]/td[2]/div/span/ul/li[2]/a");
		Thread.sleep(2000);
		webtest.type("xpath=//input[@name='cat_name']", "Next");
		webtest.click("xpath=//label[text()='是']");
		webtest.type("xpath=//input[@name='sort_order']","1");
		Thread.sleep(1000);
		webtest.type("xpath=//input[@name='keywords']", "nexttest");
		Thread.sleep(1000);
		webtest.type("xpath=//input[@name='cat_desc']", "next1");
		webtest.click("id=submitBtn");
		Thread.sleep(3000);
	}
	//删除分类
	@Test(priority = 11)
	public void DeleteKind() throws InterruptedException {
		Actions action=new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath("/html/body/div/form/div/div[4]/table/tbody/tr[3]/td[2]/div/span/em"))).perform();
		webtest.click("xpath=/html/body/div/form/div/div[4]/table/tbody/tr[3]/td[2]/div/span/ul/li[3]/a");
		Thread.sleep(2000);
		webtest.click("class=layui-layer-btn0");
		Thread.sleep(3000);
	}
	//会员协议——新增会员协议
	@Test(priority = 12)
	public void Addtreaty() throws InterruptedException {
		webtest.leaveFrame();
		webtest.click("xpath=//a[text()='页面']");
		Thread.sleep(3000);
		webtest.click("xpath=//a[text()='会员协议']");
		Thread.sleep(2000);
		webtest.enterFrame("workspace");
		webtest.click("xpath=//div[@title='新增会员协议']");
		Thread.sleep(1000);
		webtest.type("doc_title", "Test");
		Thread.sleep(1000);
		webtest.type("doc_code", "acds");
		Thread.sleep(1000);
		webtest.enterFrame("ueditor_0");
		webtest.type("xpath=//body[@class='view']", "Testtreaty");
		webtest.leaveFrame1();
		webtest.click("id=submitBtn");
		Thread.sleep(4000);
	}
//	//编辑协议信息
	@Test(priority = 13)
	public void Changetreaty() throws InterruptedException {
		webtest.click("xpath=/html/body/div[3]/div[3]/div[4]/table/tbody/tr[1]/td[2]/div/a");
		Thread.sleep(1000);
		webtest.type("id=doc_title", "Test");
		Thread.sleep(1000);
		webtest.click("id=submitBtn");
		Thread.sleep(4000);
	}
	//浏览新闻
	@Test(priority = 14)
	public void ReadNews() throws InterruptedException {
		webtest.leaveFrame();
		webtest.click("xpath=//a[text()='新闻列表']");
		Thread.sleep(2000);
		webtest.enterFrame("workspace");
		webtest.click("xpath=/html/body/div[3]/div[3]/div[3]/div[1]/table/tbody/tr[1]/td[7]/div/a[3]");
		Thread.sleep(3000);
		
	}
	//编辑新闻列表——新增新闻
	@Test(priority = 15)
	public void AddNews() throws InterruptedException {
		webtest.click("xpath=//div[@title='新增文章']");
		Thread.sleep(1000);
		webtest.type("name=title","Test");
		Thread.sleep(1000);
		webtest.click("id=cat_id");
		webtest.click("xpath=//option[@value='1']");
		Thread.sleep(1000);
		webtest.click("xpath=//div[@class='ncap-form-default']/dl[3]/dd/ul/li[1]/label/input");
		Thread.sleep(1000);
		webtest.type("name=keywords","test");
		Thread.sleep(1000);
		webtest.type("name=link","http://www.baidu.com");
		Thread.sleep(1000);
		webtest.enterFrame("ueditor_0");
		webtest.type("xpath=//body[@class='view']","TestNews");
		webtest.leaveFrame1();
		Thread.sleep(1000);
		driver.findElement(By.id("submitBtn")).click();
		Thread.sleep(4000);
	}
	//搜索新闻
	@Test(priority = 16)
	public void SearchNews() throws InterruptedException {
		webtest.click("class=select");
		webtest.click("xpath=//option[@value='1']");
		Thread.sleep(1000);
		webtest.type("class=qsbox", "Test");
		webtest.click("xpath=//input[@type='submit']");
		Thread.sleep(2000);
	}
//	//编辑新闻
	@Test(priority = 17)
	public void ChangeNews() throws InterruptedException {
		webtest.click("class=fa-refresh");
		Thread.sleep(2000);
		webtest.click("xpath=//div[@class='flexigrid']/div[3]/div[1]/table/tbody/tr[1]/td[7]/div/a[2]");
		Thread.sleep(1000);
		webtest.type("name=title","C");
		webtest.click("xpath=//div[@class='ncap-form-default']/dl[3]/dd/ul/li[1]/label/input");
		driver.findElement(By.id("submitBtn")).click();
	}

	//删除新闻
	@Test(priority = 18)
	public void DeleteNews() throws InterruptedException {
		Thread.sleep(2000);
		webtest.click("xpath=/html/body/div[3]/div[3]/div[3]/div[1]/table/tbody/tr[1]/td[7]/div/a[1]");
		Thread.sleep(1000);
		webtest.click("class=layui-layer-btn0");
		Thread.sleep(2000);
	}
//	新闻分类——新增分类
	@Test(priority = 19)
	public void AddNewKind() throws InterruptedException {
		webtest.leaveFrame();
		webtest.click("xpath=//a[text()='新闻分类']");
		webtest.enterFrame("workspace");
		webtest.click("xpath=//div[@title='新增分类']");
		Thread.sleep(1000);
		
		webtest.type("name=cat_name","Test");
		Thread.sleep(1000);
		webtest.click("xpath=//label[text()='是']");
		Thread.sleep(1000);
		webtest.type("name=sort_order","222");
		Thread.sleep(1000);
		webtest.type("name=keywords","test");
		webtest.type("name=cat_desc", "test11");
		webtest.click("id=submitBtn");
	}
	//收缩分类
	@Test(priority = 20)
	public void SNewKind() throws InterruptedException {

		webtest.click("xpath=//div[@title='收缩分类']");
		Thread.sleep(1000);
		webtest.click("xpath=//div[@title='收缩分类']");
		Thread.sleep(2000);
	}
	//编辑分类
		@Test(priority = 21)
		public void ChangeNewsKind() throws InterruptedException {
			webtest.click("xpath=/html/body/div/form/div/div[3]/table/tbody/tr[1]/td[6]/div/a[1]");
			Thread.sleep(1000);
			webtest.type("name=cat_name","Test");
			webtest.click("id=submitBtn");
			Thread.sleep(2000);
		}
		//删除分类
		@Test(priority = 22)
		public void DeleteNewsKind() throws InterruptedException {
			webtest.click("xpath=/html/body/div/form/div/div[3]/table/tbody/tr[6]/td[6]/div/a[2]");
			Thread.sleep(1000);
			webtest.click("class=layui-layer-btn0");
			Thread.sleep(2000);
		}
		//友情链接——新增友情链接
		@Test(priority = 23)
		public void AddLink() throws InterruptedException {
			webtest.leaveFrame();
			webtest.click("xpath=//a[text()='友情链接']");
			webtest.enterFrame("workspace");
			webtest.click("xpath=//div[@title='新增友情链接']");
			Thread.sleep(1000);
			webtest.type("id=link_name","Test");
			Thread.sleep(1000);
			webtest.type("id=link_url","http://www.baidu.com");
			Thread.sleep(1000);
			webtest.type("id=orderby","222");
			Thread.sleep(1000);
			webtest.click("id=submitBtn");
		}
		//编辑链接
		@Test(priority = 24)
		public void ChangeLink() throws InterruptedException {
			webtest.click("xpath=/html/body/div[3]/div[3]/div[3]/div[1]/table/tbody/tr[10]/td[7]/div/a[1]");
			Thread.sleep(1000);
			webtest.type("id=link_name","C");
			webtest.click("id=submitBtn");
			Thread.sleep(2000);
		}
		//删除链接
		@Test(priority = 25)
		public void DeleteLink() throws InterruptedException {
			webtest.click("xpath=/html/body/div[3]/div[3]/div[3]/div[1]/table/tbody/tr[10]/td[7]/div/a[2]");
			Thread.sleep(1000);
			webtest.click("class=layui-layer-btn0");
			Thread.sleep(2000);
		}
}
