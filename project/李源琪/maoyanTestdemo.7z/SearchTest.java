package com.webtest.demo;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.webtest.core.BaseTest;
import com.webtest.dataprovider.ExcelDataProvider;




public class SearchTest extends BaseTest{
	
	@DataProvider(name="search")
	public Object[][] searchTestdemo() throws IOException{
		ExcelDataProvider data=new ExcelDataProvider();
		return data.getTestDataByExcel("E://TpShopDemo//TestDemoData.xlsx", "Sheet1");
	}
	//输入英文
	@Test(dataProvider="search")
	public void inputAdd2(String shopName) throws InterruptedException {
		webtest.open("http://127.0.0.1:65/");
		Thread.sleep(1000);

		webtest.typeAndClear("class=ecsc-search-input", shopName);
		webtest.click("class=ecsc-search-button");
		Thread.sleep(3000);
	}


}

