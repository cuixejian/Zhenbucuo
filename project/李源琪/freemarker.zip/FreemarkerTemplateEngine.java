package com.webtest.utils;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import freemarker.template.Configuration;
import freemarker.template.DefaultObjectWrapper;
import freemarker.template.ObjectWrapper;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import freemarker.template.TemplateExceptionHandler;
import freemarker.template.DefaultObjectWrapper;

public class FreemarkerTemplateEngine {


	
	
	//构造Configuration
	  private static final String DEFAULT_TEMPLATE = "conf/reportTemplate.ftl";   
	    public String getTemplatePath() {   
	        return "";   
	    }   
	         
		public String run(Map context) throws Exception {
			
			return executeFreemarker(context); 
		}
	    
		private String executeFreemarker(Map context)throws Exception{   
	    	String content="";
	        Configuration cfg = new Configuration();   
	        cfg.setDirectoryForTemplateLoading(   
	                new File(getTemplatePath()));   
	       
	        cfg.setDefaultEncoding("UTF-8");
	        cfg.setObjectWrapper(new DefaultObjectWrapper());   
	        cfg.setCacheStorage(new freemarker.cache.MruCacheStorage(20, 250));                      

	      
	        Template temp = cfg.getTemplate(getTemplate());
	        StringWriter out = new StringWriter(); 
	        temp.process(context, out); 
	        return out.toString();
	    }   
	  
	    public String getTemplate() {   
	        // TODO Auto-generated method stub   
	        return DEFAULT_TEMPLATE;   
	    }





	 
}
