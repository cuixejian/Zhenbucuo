package demo;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.Test;

public class Demo1111 {
	@Test
	public void test1() {
		assertEquals(1, 1);
	}
	
}
