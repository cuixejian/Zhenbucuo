package demo1;

import static org.testng.Assert.assertTrue;

import java.sql.Driver;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.webtest.core.BaseTest;

public class LoginTest extends BaseTest{	
	
//	��½��̨�����Ӫ�����������/��ɱ��������ӻ��	
	@Test(priority = 1)
	public void testLogin() throws InterruptedException {
//		�ɹ���½
		webtest.open("http://localhost:82/index.php/Admin/Admin/login");
		webtest.type("name=username", "admin");
		webtest.type("name=password", "123456");
		webtest.type("name=vertify", "yzm");
		webtest.click("name=submit");

		webtest.click("link=Ӫ��");
		webtest.click("link=��������");
		webtest.enterFrame("workspace");  //11-20
		webtest.click("xpath=//div[@title='���ӻ']");
		
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//�������ڸ�ʽ
        String titleString = df.format(new Date());// new Date()Ϊ��ȡ��ǰϵͳʱ��
		webtest.type("name=title",titleString);	
		
		webtest.click("link=ѡ����Ʒ");
		webtest.enterFrame("layui-layer-iframe1");
//		webtest.click("xpath=//input[@data-id='317']");
		webtest.click("name=goods_id");
		webtest.runJs("window.scrollTo(0,document.body.scrollHeight)");  //ִ��js���
		webtest.click("xpath=//a[@onclick='select_goods();']");
		webtest.leaveFrame();
		webtest.enterFrame("workspace"); 
		webtest.type("name=price", "20");
		
		webtest.type("name=goods_num", "10");
		webtest.type("name=buy_limit", "1");
		webtest.runJs("window.scrollTo(0,document.body.scrollHeight)");
		webtest.click("link=ȷ���ύ");
	
	}	
	
	//@Test(priority = 2)
//	ʹ����������ѡ����Ʒ����ʱ�����۸����ԭ�ȼ۸�վ��֪ͨѡ��񣬵��ȷ���ύ��
	public void test2() throws InterruptedException {
		webtest.click("xpath=//div[@title='���ӻ']");
		
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//�������ڸ�ʽ
        String titleString = df.format(new Date());// new Date()Ϊ��ȡ��ǰϵͳʱ��
		webtest.type("name=title",titleString);	
		
		webtest.click("link=ѡ����Ʒ");
		webtest.enterFrame("layui-layer-iframe1");
		webtest.selectByValue("name=intro", "is_new");
		webtest.click("xpath=//input[@value='����']");
		webtest.click("name=goods_id");
		webtest.click("xpath=//a[@onclick='select_goods();']");

		webtest.leaveFrame();
		webtest.enterFrame("workspace"); 
		webtest.type("name=price", "20");
		
		webtest.type("name=goods_num", "10");
		webtest.type("name=buy_limit", "1");
		webtest.runJs("window.scrollTo(0,document.body.scrollHeight)");
		webtest.click("xpath=//label[@for='mmt_message_switch0']");
		webtest.click("link=ȷ���ύ");
	
	}	
	
	//@Test(priority = 3)
//	ʹ����������
	public void test3() throws InterruptedException {
		webtest.click("xpath=//div[@title='���ӻ']");
		
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//�������ڸ�ʽ
        String titleString = df.format(new Date());// new Date()Ϊ��ȡ��ǰϵͳʱ��
		webtest.type("name=title",titleString);	
		
		webtest.click("link=ѡ����Ʒ");
		webtest.enterFrame("layui-layer-iframe1");
		webtest.selectByValue("name=intro", "is_new");
		webtest.type("name=keywords", "1");
//		webtest.click("xpath=//input[@value='����']");
		webtest.click("name=goods_id");
		webtest.click("xpath=//a[@onclick='select_goods();']");

		webtest.leaveFrame();
		webtest.enterFrame("workspace"); 
		webtest.type("name=price", "20");
		
		webtest.type("name=goods_num", "10");
		webtest.type("name=buy_limit", "1");
		webtest.runJs("window.scrollTo(0,document.body.scrollHeight)");
		webtest.click("xpath=//label[@for='mmt_message_switch0']");
		webtest.click("link=ȷ���ύ");
	
	}	
	
	@Test(priority = 4)
//	��Ʒ�鿴
	public void test4() throws InterruptedException {
		webtest.click("xpath=//div[@title='���ӻ']");
		
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//�������ڸ�ʽ
        String titleString = df.format(new Date());// new Date()Ϊ��ȡ��ǰϵͳʱ��
		webtest.type("name=title",titleString);	
		
		webtest.click("link=ѡ����Ʒ");
		webtest.enterFrame("layui-layer-iframe1");
		
		webtest.click("link=�鿴");
		webtest.switchWidow(0);
	}	
	
//	���ˢ��
	@Test(priority = 5)
	public void testClick5() throws InterruptedException {
		webtest.open("http://localhost:82/index.php/Admin/Admin/login");
		webtest.type("name=username", "admin");
		webtest.type("name=password", "123456");
		webtest.type("name=vertify", "yzm");
		webtest.click("name=submit");

		webtest.click("link=Ӫ��");
		webtest.click("link=��������");
		webtest.enterFrame("workspace");  //11-20
		webtest.click("xpath=//div[@title='ˢ������']");
	//	assertTrue(webtest.isTextPresent("LAVOR"));
	}		
//	�������
	@Test(priority = 6)
	public void testClick6() throws InterruptedException {
		webtest.click("link=����");
		Thread.sleep(3000);
		assertTrue(webtest.isTextPresent("ʹ���ֲ�"));
	}	
	
//	���ɾ��
	@Test(priority = 7)
	public void testDelete7() throws InterruptedException {
		webtest.open("http://localhost:82/index.php/Admin/Admin/login");
		webtest.type("name=username", "admin");
		webtest.type("name=password", "123456");
		webtest.type("name=vertify", "yzm");
		webtest.click("name=submit");
	
		webtest.click("link=Ӫ��");
		webtest.click("link=��������");
		webtest.enterFrame("workspace");  //11-20	
		webtest.click("link=ɾ��");
		webtest.click("link=ȷ��");
	}	
	
//	����༭
	@Test(priority = 8)
	public void testBJ8() throws InterruptedException {
		webtest.open("http://localhost:82/index.php/Admin/Admin/login");
		webtest.type("name=username", "admin");
		webtest.type("name=password", "123456");
		webtest.type("name=vertify", "yzm");
		webtest.click("name=submit");
	
		webtest.click("link=Ӫ��");
		webtest.click("link=��������");
		webtest.enterFrame("workspace");  //11-20	
		webtest.click("link=�༭");
		webtest.runJs("window.scrollTo(0,document.body.scrollHeight)");
		webtest.click("link=ȷ���ύ");
	}	
	
//	���ȫѡɾ��
	@Test(priority = 10)
	public void testDeleall10() throws InterruptedException {
		webtest.open("http://localhost:82/index.php/Admin/Admin/login");
		webtest.type("name=username", "admin");
		webtest.type("name=password", "123456");
		webtest.type("name=vertify", "yzm");
		webtest.click("name=submit");
	
		webtest.click("link=Ӫ��");
		webtest.click("link=��������");
		webtest.enterFrame("workspace");  //11-20	
		webtest.click("xpath=//i[@class='ico-check']");
		webtest.click("link=ɾ��");
		webtest.click("link=ȷ��");
	}	
	
//	���ȫѡ�༭
	@Test(priority = 11)
	public void testBj11() throws InterruptedException {
		webtest.open("http://localhost:82/index.php/Admin/Admin/login");
		webtest.type("name=username", "admin");
		webtest.type("name=password", "123456");
		webtest.type("name=vertify", "yzm");
		webtest.click("name=submit");
	
		webtest.click("link=Ӫ��");
		webtest.click("link=��������");
		webtest.enterFrame("workspace");  //11-20	
		webtest.click("xpath=//i[@class='ico-check']");
		webtest.click("link=�༭");
		webtest.runJs("window.scrollTo(0,document.body.scrollHeight)");
		webtest.click("link=ȷ���ύ");
	}	
	
//	������������ʾ
	@Test(priority = 12)
	public void testBj12() throws InterruptedException {
		webtest.open("http://localhost:82/index.php/Admin/Admin/login");
		webtest.type("name=username", "admin");
		webtest.type("name=password", "123456");
		webtest.type("name=vertify", "yzm");
		webtest.click("name=submit");
	
		webtest.click("link=Ӫ��");
		webtest.click("link=��������");
		webtest.enterFrame("workspace");  //11-20	
		webtest.click("xpath=//h4[@title='��ʾ������ò���ʱӦע���Ҫ��']");
	}
//	����򿪲�����ʾ
	@Test(priority = 13)
	public void test13() throws InterruptedException {
		webtest.enterFrame("workspace");  //11-20	
		webtest.click("xpath=//h4[@title='��ʾ������ò���ʱӦע���Ҫ��']");
	}	
//	�����һҳ
	@Test(priority = 14)
	public void test14() {
		webtest.enterFrame("workspace");
		webtest.runJs("window.scrollTo(0,document.body.scrollHeight)");
		webtest.click("link=��һҳ");
	}
//	�������ҳ
	@Test(priority = 15)
	public void test15() {
		webtest.enterFrame("workspace");
		webtest.runJs("window.scrollTo(0,document.body.scrollHeight)");
		webtest.click("link=3");
	}
//	�����һҳ
	@Test(priority = 16)
	public void test16() {
		webtest.enterFrame("workspace");
		webtest.runJs("window.scrollTo(0,document.body.scrollHeight)");
		webtest.click("link=��һҳ");
	}
//����Ź�
	@Test(priority = 18)
	public void test18() throws InterruptedException {
		webtest.click("link=Ӫ��");
		webtest.click("link=�Ź�����");
		webtest.enterFrame("workspace");  //11-20
		webtest.click("xpath=//div[@title='�����Ź�']");
							
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//�������ڸ�ʽ
        String titleString = df.format(new Date());// new Date()Ϊ��ȡ��ǰϵͳʱ��
		webtest.type("name=title",titleString);	
//		webtest.click("id=start_time");
//		webtest.type("id=end_time", titleString);
//		
		webtest.click("link=ѡ����Ʒ");
		webtest.enterFrame("layui-layer-iframe1");
		webtest.click("name=goods_id");
		webtest.runJs("window.scrollTo(0,document.body.scrollHeight)");  //ִ��js���
		webtest.click("xpath=//a[@onclick='select_goods();']");
		webtest.leaveFrame();
		webtest.enterFrame("workspace"); 
		webtest.type("name=price", "1");
		
		webtest.type("name=goods_num", "1");
		webtest.type("name=virtual_num", "1");
		webtest.runJs("window.scrollTo(0,document.body.scrollHeight)");
		webtest.click("link=ȷ���ύ");
	}	
	
//	�Żݴ���
	@Test(priority = 22)
	public void test22() throws InterruptedException {
		webtest.click("link=�Żݴ���");
		webtest.enterFrame("workspace");  //11-20
		webtest.click("link=�鿴��Ʒ");
		webtest.enterFrame("layui-layer-iframe2");
		webtest.click("xpath=//a[@class='layui-layer-ico layui-layer-close layui-layer-close1']");
		webtest.enterFrame("workspace");
		
	}	
	
//	�Żݴ���
	@Test(priority = 23)
	public void test23() throws InterruptedException {
		
		webtest.open("http://localhost:82/index.php/Admin/Admin/login");
		webtest.type("name=username", "admin");
		webtest.type("name=password", "123456");
		webtest.type("name=vertify", "yzm");
		webtest.click("name=submit");

		webtest.click("link=Ӫ��");
		
		webtest.click("link=�Żݴ���");
		webtest.enterFrame("workspace");  //11-20
		webtest.click("xpath=//div[@title='���ӻ']");
		
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//�������ڸ�ʽ
        String titleString = df.format(new Date());// new Date()Ϊ��ȡ��ǰϵͳʱ��
		webtest.type("name=title",titleString);	
		webtest.type("name=expression","100");
		webtest.type("name=buy_limit", "1");
		webtest.runJs("window.scrollTo(0,document.body.scrollHeight)");  //ִ��js���
		webtest.click("xpath=//input[@title='���ǰ��Ԥ��ͼ�ɲ鿴��ͼ�������ťѡ���ļ����ύ�������ϴ���Ч']");
		
		webtest.enterFrame1("xpath=//*[@allowtransparency='true']");
		webtest.click("xpath=//li[@id='manage_tab']");
		webtest.click("xpath=//span[@class='icon']");
		webtest.click("xpath=//li[@class='btn sure checked']");
		webtest.leaveFrame();
		webtest.enterFrame("workspace");
		webtest.click("link=ѡ����Ʒ");
		webtest.enterFrame1("xpath=//*[@allowtransparency='true']");
		webtest.click("name=goods_id[]");	
		webtest.runJs("window.scrollTo(0,document.body.scrollHeight)");  
		webtest.click("xpath=//a[@onclick='select_goods();']");
		webtest.leaveFrame();
		webtest.enterFrame("workspace"); 
		webtest.click("link=ȷ���ύ");
		
	}	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
