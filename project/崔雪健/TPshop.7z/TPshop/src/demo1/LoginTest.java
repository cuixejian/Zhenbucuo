package demo1;

import static org.testng.Assert.assertTrue;

import org.testng.annotations.Test;

import com.webtest.core.BaseTest;

public class LoginTest extends BaseTest{
	@Test
	public void testLogin1() throws InterruptedException {
		
		webtest.open("http://localhost:82/Home/user/login.html");
		webtest.type("name=username", "13800138006");
		webtest.type("name=password", "123456");
		webtest.type("name=verify_code", "yzm");
		webtest.click("name=sbtbutton");
		Thread.sleep(3000);
		assertTrue(webtest.isTextPresent("�˳�"));
		Thread.sleep(3000);
	}
	
}
