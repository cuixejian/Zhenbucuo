package class1;

import java.io.IOException;

import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.TestRunner;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class Demo {
	@BeforeSuite
	public void addListener(ITestContext context) {
		System.out.println("���Ӽ�����");
		TestRunner runner = (TestRunner)context;
		runner.addListener(new JavaMailTestListener());
	}

    @Test
    public void test1() {
        Assert.assertEquals(1, 1);
    }
    @Test
    public void test2() {
        Assert.assertEquals(1, 1);
    }
    @Test
    public void test3() {
        Assert.assertEquals(3, 1);
    }
    @Test
    public void test4() {
        Assert.assertEquals(4, 1);
    }
    @Test
    public void test5() {
        Assert.assertEquals(5, 1);
    }
    @AfterSuite
    public void testdemo() throws IOException{
    	 MailUtil sendMail =new MailUtil(JavaMailTestListener.aString);
    }
   
    
}
