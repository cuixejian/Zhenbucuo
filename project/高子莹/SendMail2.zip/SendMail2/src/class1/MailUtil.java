package class1;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class MailUtil {
	public static String getPropertyValue(String key) throws IOException {
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream("conf/config.properties");
		prop.load(fis);
		fis.close();
		return prop.getProperty(key);

	}

	public MailUtil(String aString) throws IOException {

		System.out.println(aString);
		String to = getPropertyValue("tomail");
		String[] strArray = null;
		strArray = to.split(",");
		for (int i = 0; i < strArray.length; i++) {
			System.out.println(strArray[i]);
		}
//		String sender = "cuixuejian2020@126.com";
		String sender = "gaoziying2020@163.com";
		// ��Ȩ��
//		String auth_code = "LZKQWUIBCNFPLVKM";
		String auth_code = "ZRVLCTEVDGVPHJHR";
		Properties props = new Properties();
		props.put("mail.transport.protocol", "smtp");
		props.put("mail.smtp.host", "smtp.163.com");
		props.put("mail.smtp.auth", true);

		// 1������Session�����ʼ��Ự���󣩣����÷���������Ȩ�룬��ҪProperties����
		Session session = Session.getInstance(props, new Authenticator() {

			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				// TODO Auto-generated method stub
				return new PasswordAuthentication(sender, auth_code);
			}

		});

		// 2�������ʼ�������Message�������� MimeMessage
		// ���÷����ˡ��ռ��ˡ����⡢����
		for (int j = 0; j < strArray.length; j++) {
			Message message = new MimeMessage(session);
			try {
				message.setFrom(new InternetAddress(sender));
				message.addRecipient(Message.RecipientType.TO, new InternetAddress(strArray[j]));
				message.setSubject("TSShop ʧ�ܵĲ������������ͷ���");
				message.setText(aString);
				// 3�������ʼ�
				Transport.send(message);
			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
