package TestDemo;

import com.webtest.core.BaseTest;

import org.testng.Assert;
import org.testng.annotations.Test;
public class Testlogin extends BaseTest{
	
	public void Login() {
		webtest.open("http://localhost:9999/");
		webtest.click("link=��¼");
		webtest.type("name=username","13800138006");
		webtest.type("name=password","123456");
		webtest.type("name=verify_code", "aaaa");
		webtest.click("name=sbtbutton");
	}
	
	public void FindElement() {
		webtest.open("http://localhost:9999/");
		webtest.open("http://localhost:9999/index.php?m=Home&c=Goods&a=integralMall");
	}
	public void FindElement2() {
		webtest.open("http://localhost:9999/");
		webtest.open("http://localhost:9999/index.php/Home/Goods/goodsInfo/id/27");
	}
	@Test(priority=1)
	public void furnitureChoice1() throws InterruptedException {
		FindElement();
		Thread.sleep(1000);
		webtest.click("link=����");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='sbox']"));
	}
	@Test(priority=2)
	public void furnitureChoice2() throws InterruptedException {
		FindElement();
		Thread.sleep(1000);
		webtest.click("xpath=//a[@href='/index.php/Home/Goods/integralMall/brandType/1.html']");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='jpateki p']"));		

	}
	@Test(priority=3)
	public void furnitureButton3() throws InterruptedException {
		FindElement();
		Thread.sleep(1000);
		webtest.click("xpath=//a[@href='/index.php/Home/Goods/goodsInfo/id/27.html']");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='jdetail-ggsl']"));		
	}
	@Test(priority=4)
	public void furnitureChoice4() throws InterruptedException {
		FindElement();
		Thread.sleep(1000);
		webtest.click("xpath=//a[@href='/index.php/Home/Goods/integralMall/brandType/1.html']");
		Thread.sleep(1000);
		webtest.click("link=���ɸѡ����");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='jpateki p']"));
	}
	@Test(priority=5)
	public void furnitureChoice5() throws InterruptedException {
		FindElement();
		Thread.sleep(1000);
		webtest.click("link=����");
		Thread.sleep(1000);
		webtest.click("link=���ɸѡ����");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='jpateki p']"));
	}
	@Test(priority=6)
	public void furnitureChoice6() throws InterruptedException {
		FindElement();
		Thread.sleep(1000);
		webtest.click("link=����");
		Thread.sleep(1000);
		webtest.click("xpath=//a[@href='/index.php/Home/Goods/integralMall/id/12/brandType/1.html']");
		Thread.sleep(1000);
		webtest.click("link=���ɸѡ����");
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='jpateki p']"));
	}
	@Test(priority=7)
	public void furnitureChoice7() throws InterruptedException {
		FindElement2();
		Thread.sleep(1000);
		webtest.click("link=+");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='minus-plus']"));
	}
	@Test(priority=8)
	public void furnitureChoice8() throws InterruptedException {
		FindElement();
		Thread.sleep(1000);
		webtest.click("link=����");
		Thread.sleep(1000);
		webtest.click("link=ȫ�����");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='jpateki p']"));
	}
	@Test(priority=9)
	public void furnitureChoice9() throws InterruptedException {
		FindElement2();
		Thread.sleep(1000);
		webtest.click("link=Sony/���� MDR-EX155AP ���ʽ����ͨ���ص����ֻ��߿ش���ͨ��");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='jdetail-ggsl']"));
	}
	@Test(priority=10)
	public void furnitureChoice10() throws InterruptedException {
		FindElement2();
		Thread.sleep(1000);
		webtest.click("link=��Ʒ����");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='deta-descri']"));
	}
	@Test(priority=11)
	public void furnitureChoice11() throws InterruptedException {
		FindElement2();
		Thread.sleep(1000);
		webtest.click("link=��񼰰�װ");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='introduceshop']"));
	}
	@Test(priority=12)
	public void furnitureChoice12() throws InterruptedException {
		FindElement2();
		Thread.sleep(1000);
		webtest.click("link=�ۺ����");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='shop-describe p']"));
	}
	@Test(priority=13)
	public void furnitureChoice13() throws InterruptedException {
		FindElement2();
		Thread.sleep(1000);
		webtest.mouseToElement("xpath=//img[@src='/public/upload/goods/thumb/27/goods_sub_thumb_113_60_60.jpeg\']");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='sproduct-img jqzoom']"));
	}
	@Test(priority=14)
	public void furnitureChoice14() throws InterruptedException {
		FindElement2();
		Thread.sleep(1000);
		webtest.click("link=��һ��");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='alone-shop']"));
	}
	@Test(priority=15)
	public void furnitureButton15() throws InterruptedException {
		FindElement();
		Thread.sleep(1000);
		webtest.runJs("window.scrollTo(0,2000)");
		Thread.sleep(2000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='tpshop-service']"));
	}
	@Test(priority=16)
	public void furnitureChoice16() throws InterruptedException {
		FindElement2();
		Thread.sleep(1000);
		webtest.click("class=goods_dispatching_name");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='content']"));
	}
	@Test//(priority=17)
	public void furnitureChoice17() throws InterruptedException {
		FindElement2();
		Thread.sleep(1000);
		webtest.click("class=detai-ico");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='online-service fr p']"));
	}
	@Test(priority=18)
	public void furnitureChoice18() throws InterruptedException {
		FindElement2();
		Thread.sleep(1000);
		webtest.click("class=bds_qzone");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='bdsharebuttonbox bdshare-button-style0-16']"));
	}
	@Test(priority=19)
	public void furnitureChoice19() throws InterruptedException {
		Login();
		Thread.sleep(1000);
		FindElement2();
		Thread.sleep(1000);
		webtest.click("link=�����һ�");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='fillorder']"));
	}
	@Test(priority=20)
	public void furnitureChoice20() throws InterruptedException {
		FindElement2();
		Thread.sleep(1000);
		webtest.click("link=�ֻ�");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='shop-list-splb p']"));
	}
	@Test(priority=21)
	public void furnitureChoice21() throws InterruptedException {
		FindElement2();
		Thread.sleep(1000);
		webtest.click("xpath=//a[@href='/index.php/Home/Goods/goodsInfo/id/312.html']");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='detail-ggsl']"));
	}
	@Test(priority=22)
	public void furnitureChoice22() throws InterruptedException {
		FindElement2();
		Thread.sleep(1000);
		webtest.click("link=�ۺ����");
		Thread.sleep(1000);
		webtest.click("class=consult-ac");
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='publish-title']"));
	}
	@Test(priority=23)
	public void furnitureChoice23() throws InterruptedException {
		FindElement2();
		Thread.sleep(1000);
		webtest.mouseToElement("xpath=//img[@src='/public/upload/goods/thumb/16/goods_thumb_16_0_206_206.png']");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='publish-title']"));
	}
	@Test(priority=24)
	public void furnitureChoice24() throws InterruptedException {
		FindElement2();
		Thread.sleep(1000);
		webtest.type("class=buyNum", "200");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='standard p']"));
	}
	@Test(priority=25)
	public void furnitureChoice25() throws InterruptedException {
		Login();
		Thread.sleep(1000);
		FindElement2();
		Thread.sleep(1000);
		webtest.type("class=buyNum", "w");
		Thread.sleep(1000);
		webtest.click("link=�����һ�");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='fillorder']"));
	}
	@Test(priority=26)
	public void furnitureChoice26() throws InterruptedException {
		
		FindElement2();
		Thread.sleep(1000);
		webtest.click("xpath=//a[@href='javascript:void(0);']/em");
		Thread.sleep(1000);
		webtest.click("link=��������");
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='menumain p']"));
	}
	@Test(priority=27)
	public void furnitureChoice27() throws InterruptedException {
		FindElement2();
		Thread.sleep(1000);
		webtest.click("link=�ֻ����");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='shop_name2']"));
	}
	@Test(priority=28)
	public void furnitureChoice28() throws InterruptedException {
		Login();
		Thread.sleep(1000);
		FindElement2();
		Thread.sleep(1000);
		webtest.click("xpath=//i[@class='share-shopcar-index']");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='menu-ri-t p']"));
	}
	@Test(priority=29)
	public void furnitureChoice29() throws InterruptedException {
		Login();
		Thread.sleep(1000);
		FindElement2();
		Thread.sleep(1000);
		webtest.click("xpath=//a[@href='javascript:void(0);']/em");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='nchx_com']"));
	}
	@Test(priority=30)
	public void furnitureChoice30() throws InterruptedException {
		FindElement2();
		Thread.sleep(1000);
		webtest.type("xpath=//input[@class='ecsc-search-input']", "�ֻ�");
		Thread.sleep(1000);
		webtest.click("xpath=//button[@class='ecsc-search-button']");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@id='shop-list-tour ma-to-20 p']"));
	}
	@Test(priority=31)
	public void furnitureChoice31() throws InterruptedException {
		FindElement2();
		Thread.sleep(1000);
		webtest.click("xpath=//img[@src='/public/upload/logo/2018/04-09/814d7e9a0eddcf3754f2e8373a50a19c.png']");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@id='myCarousel']"));
	}
	@Test//(priority=32)
	public void furnitureChoice32() throws InterruptedException {
		FindElement2();
		Thread.sleep(1000);
		webtest.click("link=�Ա���");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='logo']"));
	}
	@Test(priority=33)
	public void furnitureChoice33() throws InterruptedException {
		FindElement2();
		Thread.sleep(1000);
		webtest.runJs("window.scrollTo(0,4000)");
		Thread.sleep(2000);
		webtest.click("link=���׽캣Ͽ������Ӱ����Ӱչ");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='hc-column']"));
	}
	@Test(priority=34)
	public void furnitureChoice34() throws InterruptedException {
		FindElement2();
		Thread.sleep(1000);
		webtest.runJs("window.scrollTo(0,4000)");
		Thread.sleep(2000);
		webtest.click("link=��Ӫ����վ��������");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='tpshop-tm-hander']"));
	}
	@Test(priority=35)
	public void furnitureChoice35() throws InterruptedException {
		Login();
		Thread.sleep(1000);
		FindElement2();
		Thread.sleep(1000);
		webtest.runJs("window.scrollTo(0,4000)");
		Thread.sleep(2000);
		webtest.click("link=���ض���");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='tpshop-tm-hander']"));
	}
	@Test(priority=36)
	public void furnitureChoice36() throws InterruptedException {
		Login();
		Thread.sleep(1000);
		FindElement2();
		Thread.sleep(1000);
		webtest.click("link=������ѯ");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='tpshop-tm-hander']"));
	}
	@Test(priority=37)
	public void furnitureChoice37() throws InterruptedException {
		Login();
		Thread.sleep(1000);
		FindElement2();
		Thread.sleep(1000);
		webtest.click("link=�ղ�");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='tpshop-tm-hander']"));
	}
	@Test(priority=38)
	public void furnitureChoice38() throws InterruptedException {
		Login();
		Thread.sleep(1000);
		FindElement2();
		Thread.sleep(1000);
		webtest.click("link=�ղ���Ʒ");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='tpshop-tm-hander']"));
	}
	@Test(priority=39)
	public void furnitureChoice39() throws InterruptedException {
		Login();
		Thread.sleep(1000);
		FindElement2();
		Thread.sleep(1000);
		webtest.click("link=��Ϣ");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='home-index-middle']"));
	}
	@Test(priority=40)
	public void furnitureChoice40() throws InterruptedException {
		FindElement2();
		Thread.sleep(1000);
		webtest.click("xpath=//div[@class='categorys home_categorys']");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='tpshop-tm-hander']"));
	}
	@Test(priority=41)
	public void furnitureChoice41() throws InterruptedException {
		FindElement();
		Thread.sleep(1000);
		webtest.click("link=ע��");
		Thread.sleep(2000);
		webtest.click("link=����ע��");
		Thread.sleep(2000);
		webtest.type("inp J_cellphone", "13860606060");
		Thread.sleep(1000);
		webtest.type("inp imgcode J_imgcode", "aaaa");
		Thread.sleep(1000);
		webtest.type("inp fpass J_password", "abc123");
		Thread.sleep(1000);
		webtest.type("inp fpass J_password2", "abc123");
		Thread.sleep(1000);
		webtest.click("link=ͬ��Э�鲢ע��");
		Thread.sleep(2000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='tm-fnbox ui_panel']"));
	}
	@Test(priority=42)
	public void furnitureChoice42() throws InterruptedException {
		FindElement();
		Thread.sleep(1000);
		webtest.click("link=ע��");
		Thread.sleep(2000);
		webtest.type("inp fmobile J_cellphone", "13860606060");
		Thread.sleep(1000);
		webtest.type("inp imgcode J_imgcode", "aaaa");
		Thread.sleep(1000);
		webtest.type("inp fpass J_password", "abc123");
		Thread.sleep(1000);
		webtest.type("inp fpass J_password2", "abc123");
		Thread.sleep(1000);
		webtest.click("link=ͬ��Э�鲢ע��");
		Thread.sleep(2000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='tm-fnbox ui_panel']"));
	}
	@Test(priority=43)
	public void furnitureChoice43() throws InterruptedException {
		FindElement();
		Thread.sleep(1000);
		webtest.click("xpath=//div[@class='text']");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='content']"));
	}
	@Test(priority=44)
	public void furnitureChoice44() throws InterruptedException {
		FindElement();
		Thread.sleep(1000);
		webtest.click("xpath=//div[@class='text']");
		Thread.sleep(1000);
		webtest.click("xpath=//div[@class='close']");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='tpshop-tm-hander']"));
	}
	@Test(priority=45)
	public void furnitureChoice45() throws InterruptedException {
		FindElement();
		Thread.sleep(1000);
		webtest.runJs("window.scrollTo(0,3000)");
		Thread.sleep(2000);
		webtest.click("xpath=//img[@src='/public/upload/goods/thumb/27/goods_thumb_27_0_165_188.jpeg']");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='tpshop-tm-hander']"));
	}
	@Test(priority=46)
	public void furnitureChoice46() throws InterruptedException {
		FindElement();
		Thread.sleep(1000);
		webtest.runJs("window.scrollTo(0,3000)");
		Thread.sleep(2000);
		webtest.click("xpath=//a[@href='//public/upload/goods/thumb/93/goods_thumb_93_0_165_188.jpeg']");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='tpshop-tm-hander']"));
	}
	@Test(priority=47)
	public void furnitureChoice47() throws InterruptedException {
		Login();
		Thread.sleep(1000);
		FindElement();
		Thread.sleep(1000);
		webtest.click("link=��ȫ�˳�");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='fl nologin']"));
	}
	@Test(priority=48)
	public void furnitureChoice48() throws InterruptedException {
		Login();
		Thread.sleep(1000);
		FindElement2();
		Thread.sleep(1000);
		webtest.click("link=�����һ�");
		Thread.sleep(1000);
		webtest.runJs("window.scrollTo(0,3000)");
		Thread.sleep(2000);
		webtest.click("link=�ύ����");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='layout after-ta order-ha']"));
	}
	@Test(priority=49)
	public void furnitureChoice49() throws InterruptedException {
		Login();
		Thread.sleep(1000);
		FindElement();
		Thread.sleep(1000);
		webtest.click("xpath=//a[@href='/index.php/Home/user/index.html']");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='fl nologin']"));
	}
	@Test(priority=50)
	public void furnitureChoice50() throws InterruptedException {
		FindElement();
	  	Thread.sleep(1000);
		webtest.mouseToElement("xpath=//div[@class='nav-dh']");
		Thread.sleep(1000);
		webtest.click("link=�һ�����");
		Thread.sleep(1000);
		Assert.assertTrue(webtest.isElementPresent("xpath=//div[@class='fl nologin']"));
	}
}  


