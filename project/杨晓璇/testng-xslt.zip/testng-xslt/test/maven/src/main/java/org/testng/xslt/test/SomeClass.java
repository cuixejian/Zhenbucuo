package org.testng.xslt.test;

/**
 * @author Cosmin Marginean, Jun 15, 2020
 */
public class SomeClass {
}
